import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Send, Sparkles, Globe, AlertTriangle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { CaseAnalysis } from "@/lib/types";

const examples = [
  { text: "My landlord is refusing to return my security deposit after I vacated the flat in Mumbai.", lang: "EN" },
  { text: "मेरे पड़ोसी ने मेरी ज़मीन पर अतिक्रमण कर लिया है और धमकी दे रहा है।", lang: "HI" },
  { text: "माझ्या मालकाने माझा पगार तीन महिन्यांपासून दिलेला नाही.", lang: "MR" },
];

const AnalyzePage = () => {
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const analyze = async () => {
    if (!input.trim()) {
      toast.error("Please enter a legal issue to analyze.");
      return;
    }
    if (input.trim().length < 10) {
      toast.error("Please provide more detail about your legal issue.");
      return;
    }
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("analyze", {
        body: { input_text: input.trim() },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      const result: CaseAnalysis = { ...data, input_text: input.trim() };
      navigate("/result", { state: { result } });
    } catch (e: any) {
      toast.error(e.message || "Analysis failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] py-12 px-4">
      <div className="container mx-auto max-w-2xl space-y-8">
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-2 bg-primary/10 px-3 py-1 rounded-full text-xs font-medium text-primary">
            <Sparkles className="h-3 w-3" /> AI-Powered Analysis
          </div>
          <h1 className="font-heading text-3xl md:text-4xl font-bold">Analyze Your Legal Case</h1>
          <p className="text-muted-foreground">Describe your legal issue in English, Hindi, or Marathi</p>
        </div>

        <div className="glass-card rounded-2xl p-8 space-y-6">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium">Your Legal Issue</label>
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <Globe className="h-3 w-3" />
                Auto-detect language
              </div>
            </div>
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Describe your legal problem in detail here... The more detail you provide, the better the analysis."
              className="min-h-[200px] text-base resize-none border-border/50 focus:ring-primary bg-secondary/30"
              disabled={loading}
            />
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span>{input.length} characters</span>
              {input.length > 0 && input.length < 10 && (
                <span className="flex items-center gap-1 text-severity-medium">
                  <AlertTriangle className="h-3 w-3" /> Please provide more detail
                </span>
              )}
            </div>
          </div>

          <Button
            onClick={analyze}
            disabled={loading || input.trim().length < 10}
            className="w-full gradient-primary border-0 text-primary-foreground h-12 text-base font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all"
          >
            {loading ? (
              <>
                <Loader2 className="h-5 w-5 animate-spin" />
                <span>Analyzing with AI...</span>
              </>
            ) : (
              <>
                <Send className="h-5 w-5" />
                <span>Analyze Case</span>
              </>
            )}
          </Button>

          {loading && (
            <div className="text-center space-y-2 animate-in fade-in">
              <div className="flex justify-center gap-1">
                {[0, 1, 2].map((i) => (
                  <div key={i} className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />
                ))}
              </div>
              <p className="text-sm text-muted-foreground">Identifying laws, assessing severity, generating recommendations...</p>
            </div>
          )}
        </div>

        <div className="space-y-3">
          <p className="text-sm text-muted-foreground font-medium">Try an example:</p>
          <div className="grid gap-3">
            {examples.map(({ text, lang }, i) => (
              <button
                key={i}
                onClick={() => setInput(text)}
                disabled={loading}
                className="w-full text-left glass-card rounded-xl px-5 py-4 text-sm hover:shadow-md transition-all group disabled:opacity-50"
              >
                <div className="flex items-start gap-3">
                  <span className="shrink-0 bg-primary/10 text-primary text-xs font-bold px-2 py-0.5 rounded-md mt-0.5">{lang}</span>
                  <span className="text-muted-foreground group-hover:text-foreground transition-colors">{text}</span>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalyzePage;
