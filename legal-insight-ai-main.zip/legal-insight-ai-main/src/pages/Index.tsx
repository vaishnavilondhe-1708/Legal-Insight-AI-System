import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Scale, Sparkles, Globe, Shield, FileText, ArrowRight, Zap, BookOpen } from "lucide-react";

const features = [
  { icon: Sparkles, title: "AI-Powered Analysis", desc: "Real LLM reasoning — not keyword matching. Every analysis is unique and context-aware." },
  { icon: Globe, title: "Multi-Language", desc: "Auto-detects English, Hindi & Marathi. Responses in the same language as your input." },
  { icon: Shield, title: "Indian Law References", desc: "Accurate IPC sections, acts, and legal provisions dynamically identified for your case." },
  { icon: FileText, title: "Detailed Reports", desc: "Structured analysis with severity, recommendations, and downloadable reports." },
];

const stats = [
  { value: "500+", label: "Legal Categories" },
  { value: "3", label: "Languages" },
  { value: "Real-time", label: "AI Analysis" },
  { value: "100%", label: "Secure" },
];

const steps = [
  { num: "01", icon: BookOpen, title: "Describe Your Issue", desc: "Enter your legal problem in natural language — English, Hindi, or Marathi." },
  { num: "02", icon: Zap, title: "AI Analyzes", desc: "Our AI identifies the category, applicable laws, severity, and provides tailored advice." },
  { num: "03", icon: FileText, title: "Get Your Report", desc: "Receive structured results with actionable recommendations and download your report." },
];

const Index = () => {
  const navigate = useNavigate();
  const { user } = useAuth();

  return (
    <div className="min-h-[calc(100vh-4rem)]">
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="gradient-hero py-28 px-4">
          <div className="absolute inset-0 opacity-10" style={{
            backgroundImage: "radial-gradient(circle at 25% 50%, hsl(220 70% 55% / 0.3), transparent 50%), radial-gradient(circle at 75% 50%, hsl(38 90% 55% / 0.2), transparent 50%)"
          }} />
          <div className="container mx-auto text-center max-w-3xl relative z-10 space-y-8">
            <div className="inline-flex items-center gap-2 bg-primary/15 backdrop-blur-sm px-4 py-2 rounded-full text-sm border border-primary/25 text-primary-foreground/80">
              <Sparkles className="h-4 w-4 text-accent" />
              AI-Powered Legal Intelligence for India
            </div>
            <h1 className="font-heading text-4xl md:text-6xl lg:text-7xl font-bold leading-[1.1] text-primary-foreground">
              AI Legal Conflict{" "}
              <span className="text-gradient">Analyzer</span>
            </h1>
            <p className="text-lg md:text-xl text-primary-foreground/60 max-w-2xl mx-auto leading-relaxed">
              Instantly analyze any legal case with AI. Get structured insights, relevant Indian laws, severity assessment, and actionable recommendations.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-2">
              <Button
                onClick={() => navigate(user ? "/analyze" : "/login")}
                className="gradient-primary border-0 text-primary-foreground h-13 px-8 text-base font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all hover:scale-105"
              >
                <Scale className="h-5 w-5 mr-2" />
                {user ? "Start Analysis" : "Get Started Free"}
                <ArrowRight className="h-4 w-4 ml-1" />
              </Button>
              {!user && (
                <Button
                  variant="outline"
                  onClick={() => navigate("/login")}
                  className="h-13 px-8 text-base rounded-xl border-primary-foreground/20 text-primary-foreground/80 hover:bg-primary-foreground/10 bg-transparent"
                >
                  Sign In
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* Stats bar */}
        <div className="bg-card border-y">
          <div className="container mx-auto grid grid-cols-2 md:grid-cols-4 divide-x">
            {stats.map(({ value, label }) => (
              <div key={label} className="py-6 text-center">
                <div className="font-heading text-2xl font-bold text-primary">{value}</div>
                <div className="text-xs text-muted-foreground mt-1 uppercase tracking-wider">{label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-24 px-4 bg-secondary/30">
        <div className="container mx-auto max-w-5xl">
          <div className="text-center mb-16 space-y-3">
            <span className="text-sm font-semibold text-primary uppercase tracking-wider">How It Works</span>
            <h2 className="font-heading text-3xl md:text-4xl font-bold">Three Simple Steps</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {steps.map(({ num, icon: Icon, title, desc }) => (
              <div key={num} className="relative glass-card rounded-2xl p-8 text-center space-y-4 hover:shadow-xl transition-all duration-300 group">
                <span className="absolute top-4 right-4 text-5xl font-heading font-bold text-primary/10 group-hover:text-primary/20 transition-colors">{num}</span>
                <div className="gradient-primary w-14 h-14 rounded-2xl flex items-center justify-center mx-auto shadow-lg">
                  <Icon className="h-7 w-7 text-primary-foreground" />
                </div>
                <h3 className="font-heading text-lg font-semibold">{title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-24 px-4">
        <div className="container mx-auto max-w-5xl">
          <div className="text-center mb-16 space-y-3">
            <span className="text-sm font-semibold text-primary uppercase tracking-wider">Features</span>
            <h2 className="font-heading text-3xl md:text-4xl font-bold">Built for Indian Legal System</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {features.map(({ icon: Icon, title, desc }) => (
              <div key={title} className="glass-card rounded-2xl p-8 space-y-4 hover:shadow-xl transition-all duration-300 group">
                <div className="gradient-primary w-12 h-12 rounded-xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                  <Icon className="h-6 w-6 text-primary-foreground" />
                </div>
                <h3 className="font-heading text-lg font-semibold">{title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-3xl">
          <div className="gradient-primary rounded-3xl p-12 text-center space-y-6 shadow-2xl">
            <h2 className="font-heading text-3xl md:text-4xl font-bold text-primary-foreground">
              Ready to analyze your legal case?
            </h2>
            <p className="text-primary-foreground/70 max-w-xl mx-auto">
              Get AI-powered legal insights with accurate Indian law references in seconds.
            </p>
            <Button
              onClick={() => navigate(user ? "/analyze" : "/login")}
              className="bg-card text-foreground hover:bg-card/90 h-12 px-8 text-base font-semibold rounded-xl"
            >
              {user ? "Analyze Now" : "Get Started"} <ArrowRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-8 px-4">
        <div className="container mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Scale className="h-4 w-4 text-primary" />
            <span className="font-heading font-semibold text-sm">LegalAI</span>
          </div>
          <p className="text-xs text-muted-foreground">
            AI Legal Conflict Analyzer — For educational purposes. Not a substitute for professional legal advice.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
