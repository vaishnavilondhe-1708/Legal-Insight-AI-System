import { useLocation, Navigate } from "react-router-dom";
import ResultCard from "@/components/ResultCard";
import { CheckCircle2 } from "lucide-react";

const ResultPage = () => {
  const location = useLocation();
  const result = location.state?.result;

  if (!result) return <Navigate to="/analyze" replace />;

  return (
    <div className="min-h-[calc(100vh-4rem)] py-12 px-4">
      <div className="container mx-auto max-w-2xl space-y-8">
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-2 bg-severity-low/10 text-severity-low px-3 py-1 rounded-full text-xs font-medium">
            <CheckCircle2 className="h-3 w-3" /> Analysis Complete
          </div>
          <h1 className="font-heading text-3xl md:text-4xl font-bold">Legal Analysis Report</h1>
          <p className="text-muted-foreground">AI-generated analysis based on your input</p>
        </div>
        <ResultCard data={result} />
      </div>
    </div>
  );
};

export default ResultPage;
