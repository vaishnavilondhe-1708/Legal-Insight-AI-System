import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { CaseAnalysis } from "@/lib/types";
import ResultCard from "@/components/ResultCard";
import { Input } from "@/components/ui/input";
import { Loader2, Search, Filter, Calendar, Scale } from "lucide-react";

const HistoryPage = () => {
  const [cases, setCases] = useState<CaseAnalysis[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<CaseAnalysis | null>(null);
  const [severityFilter, setSeverityFilter] = useState<string>("all");

  useEffect(() => {
    const fetchCases = async () => {
      const { data, error } = await supabase
        .from("cases")
        .select("*")
        .order("created_at", { ascending: false });
      if (!error && data) {
        setCases(data as unknown as CaseAnalysis[]);
      }
      setLoading(false);
    };
    fetchCases();
  }, []);

  const filtered = cases.filter((c) => {
    const matchesSearch =
      c.input_text.toLowerCase().includes(search.toLowerCase()) ||
      c.category?.toLowerCase().includes(search.toLowerCase()) ||
      c.sub_category?.toLowerCase().includes(search.toLowerCase());
    const matchesSeverity = severityFilter === "all" || c.severity === severityFilter;
    return matchesSearch && matchesSeverity;
  });

  if (selected) {
    return (
      <div className="min-h-[calc(100vh-4rem)] py-12 px-4">
        <div className="container mx-auto max-w-2xl space-y-6">
          <button onClick={() => setSelected(null)} className="text-sm text-primary hover:underline font-medium">
            ← Back to History
          </button>
          <ResultCard data={selected} showActions={true} />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[calc(100vh-4rem)] py-12 px-4">
      <div className="container mx-auto max-w-3xl space-y-8">
        <div className="text-center space-y-3">
          <h1 className="font-heading text-3xl md:text-4xl font-bold">Case History</h1>
          <p className="text-muted-foreground">Browse and search your previous legal analyses</p>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by keyword, category..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex gap-2">
            {["all", "High", "Medium", "Low"].map((s) => (
              <button
                key={s}
                onClick={() => setSeverityFilter(s)}
                className={`px-3 py-2 rounded-lg text-xs font-medium border transition-all ${
                  severityFilter === s
                    ? s === "High" ? "severity-high border-current"
                    : s === "Medium" ? "severity-medium border-current"
                    : s === "Low" ? "severity-low border-current"
                    : "gradient-primary text-primary-foreground border-transparent"
                    : "bg-secondary text-muted-foreground border-border hover:bg-secondary/80"
                }`}
              >
                {s === "all" ? (
                  <span className="flex items-center gap-1"><Filter className="h-3 w-3" /> All</span>
                ) : s}
              </button>
            ))}
          </div>
        </div>

        {/* Results count */}
        {!loading && (
          <p className="text-xs text-muted-foreground">
            {filtered.length} of {cases.length} cases
          </p>
        )}

        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 gap-3">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <p className="text-sm text-muted-foreground">Loading your case history...</p>
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-20 space-y-4">
            <div className="bg-secondary/50 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto">
              <Scale className="h-8 w-8 text-muted-foreground/50" />
            </div>
            <p className="text-muted-foreground">
              {cases.length === 0 ? "No analyses yet. Start by analyzing a case!" : "No results match your search."}
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {filtered.map((c) => (
              <button
                key={c.id || c.created_at}
                onClick={() => setSelected(c)}
                className="w-full text-left glass-card rounded-xl p-5 hover:shadow-lg transition-all duration-200 space-y-3 group"
              >
                <div className="flex items-center justify-between gap-4">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="gradient-primary w-8 h-8 rounded-lg flex items-center justify-center shrink-0">
                      <Scale className="h-4 w-4 text-primary-foreground" />
                    </div>
                    <div className="min-w-0">
                      <span className="font-heading font-semibold text-sm block truncate group-hover:text-primary transition-colors">{c.category}</span>
                      <span className="text-xs text-muted-foreground">{c.sub_category}</span>
                    </div>
                  </div>
                  <span className={`text-xs font-semibold px-2.5 py-1 rounded-full border shrink-0 ${
                    c.severity === "High" ? "severity-high"
                    : c.severity === "Medium" ? "severity-medium"
                    : "severity-low"
                  }`}>
                    {c.severity}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground line-clamp-2 pl-11">{c.input_text}</p>
                {c.created_at && (
                  <div className="flex items-center gap-1 text-xs text-muted-foreground/60 pl-11">
                    <Calendar className="h-3 w-3" />
                    {new Date(c.created_at).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
                  </div>
                )}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default HistoryPage;
