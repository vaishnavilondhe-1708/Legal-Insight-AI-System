import { cn } from "@/lib/utils";

const SeverityBadge = ({ severity }: { severity: string }) => {
  const cls =
    severity === "High"
      ? "severity-high"
      : severity === "Medium"
      ? "severity-medium"
      : "severity-low";

  return (
    <span className={cn("inline-flex items-center px-3 py-1 rounded-full text-sm font-semibold border", cls)}>
      {severity}
    </span>
  );
};

export default SeverityBadge;
