export interface CaseAnalysis {
  id?: string;
  input_text: string;
  detected_language?: string;
  category: string;
  sub_category: string;
  laws: string[];
  severity: "Low" | "Medium" | "High";
  suggestion: string;
  recommended_action: string[];
  created_at?: string;
}
