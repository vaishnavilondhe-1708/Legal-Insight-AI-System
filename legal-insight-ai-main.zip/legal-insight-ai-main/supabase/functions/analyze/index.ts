import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { input_text } = await req.json();
    if (!input_text || typeof input_text !== "string" || input_text.trim().length === 0) {
      return new Response(JSON.stringify({ error: "input_text is required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Get user from auth header
    const authHeader = req.headers.get("Authorization");
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    let userId: string | null = null;
    if (authHeader) {
      const token = authHeader.replace("Bearer ", "");
      const anonClient = createClient(supabaseUrl, supabaseAnonKey);
      const { data: { user } } = await anonClient.auth.getUser(token);
      userId = user?.id || null;
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const systemPrompt = `You are an expert Indian legal analyst AI. Analyze the given legal problem and respond ONLY with valid JSON (no markdown, no code fences).

Your response must be exactly this JSON structure:
{
  "category": "string - the broad legal category (e.g., Criminal Law, Civil Law, Family Law, Property Law, Labour Law, Consumer Law, Constitutional Law, Cyber Law, etc.)",
  "sub_category": "string - specific sub-category within the category",
  "laws": ["array of relevant Indian laws, sections, and acts - e.g., 'Section 420 of Indian Penal Code, 1860', 'Consumer Protection Act, 2019'"],
  "severity": "Low or Medium or High",
  "suggestion": "string - detailed legal suggestion in the same language as input",
  "recommended_action": ["array of specific actionable steps the person should take"],
  "detected_language": "string - the language of the input: English, Hindi, or Marathi"
}

Rules:
- Dynamically determine category and sub-category based on the case
- Reference actual Indian laws, sections, and acts accurately
- Severity: High = criminal/urgent, Medium = civil disputes, Low = advisory/informational
- Provide suggestion and recommended_action in the SAME language as the input
- Be specific and practical in recommendations
- Each analysis must be unique based on the specific facts provided`;

    const aiResponse = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: input_text },
        ],
      }),
    });

    if (!aiResponse.ok) {
      if (aiResponse.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again shortly." }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (aiResponse.status === 402) {
        return new Response(JSON.stringify({ error: "AI credits exhausted. Please add funds." }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const errText = await aiResponse.text();
      console.error("AI error:", aiResponse.status, errText);
      throw new Error("AI gateway error");
    }

    const aiData = await aiResponse.json();
    let content = aiData.choices?.[0]?.message?.content || "";
    content = content.replace(/```json\s*/gi, "").replace(/```\s*/gi, "").trim();

    let analysis;
    try {
      analysis = JSON.parse(content);
    } catch {
      console.error("Failed to parse AI response:", content);
      throw new Error("Failed to parse AI analysis");
    }

    // Save to database with user_id
    const serviceClient = createClient(supabaseUrl, supabaseServiceKey);
    const { error: dbError } = await serviceClient.from("cases").insert({
      input_text: input_text.trim(),
      user_id: userId,
      detected_language: analysis.detected_language || "English",
      category: analysis.category,
      sub_category: analysis.sub_category,
      laws: analysis.laws || [],
      severity: analysis.severity,
      suggestion: analysis.suggestion,
      recommended_action: analysis.recommended_action || [],
    });

    if (dbError) console.error("DB insert error:", dbError);

    return new Response(JSON.stringify(analysis), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("analyze error:", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
