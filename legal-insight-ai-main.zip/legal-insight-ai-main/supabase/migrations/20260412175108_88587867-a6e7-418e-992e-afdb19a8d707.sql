
CREATE TABLE public.cases (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  input_text TEXT NOT NULL,
  detected_language TEXT,
  category TEXT,
  sub_category TEXT,
  laws TEXT[],
  severity TEXT,
  suggestion TEXT,
  recommended_action TEXT[],
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.cases ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view cases" ON public.cases FOR SELECT USING (true);
CREATE POLICY "Anyone can insert cases" ON public.cases FOR INSERT WITH CHECK (true);
